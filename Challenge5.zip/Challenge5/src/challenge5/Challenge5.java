/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package challenge5;

import java.util.Scanner;

/**
 *
 * @author 6306841
 * due date: 3/23/22
 */
public class Challenge5 {

      /**
     * Description:  Driver method that allows us to ask the user to insert a word with x in it
     * Then after they input the word it will ask if they wish to enter another word, using a do while.
     * @param:none
     * @return:none
     * @throws:none
     */
 
    public static void main(String[] args) {
      
        
         char capX = 'X';
         char xWord ='x' ;
         char yWord = 'y';
         char capY = 'Y';
         
        Scanner keyboard = new Scanner (System.in);
        String answer = "Yes";
        
     do {
         System.out.println("Please enter a word that has X in it");
       String word = keyboard.nextLine();
         
         
         System.out.println("Your word after we switch X: ");
         System.out.println(xyCase(word,xWord,yWord,capX,capY));
         
        
         System.out.println("Do you want to enter another word?" + "\n" + "Yes or No?");
          answer = keyboard.nextLine();
     }
     
     while (answer.equalsIgnoreCase("Yes"));
     
    }
    
     /**
     * Description: This is where we implement our base and recursive case and convert any input
     * of lower case and upper x to y.
     * @param:String word, char xWord, yWord, capX, capY
     * @return:word, xLetter xLetter + xyCase(word.substring(1), xWord, yWord, capX, capY) ;
     * @throws:none
     */
    public static String xyCase (String word, char xWord, char yWord, char capX, char capY) 
    {
      
        
       // base case becasue it returns our string
       if (word.isEmpty())
          
       {
            return word;
       }
        char xLetter = word.charAt(0);
        
        
    // recursive 
        if ( word.charAt(0)==xWord)
       {
           xLetter = yWord ;
          
           word = yWord + word.substring(1); 
        }
        
     if (word.charAt(0)== capX)
        {
            
            xLetter = capY;
             word = capY + word.substring(1);
        }
               
         
      return xLetter + xyCase(word.substring(1), xWord, yWord, capX, capY) ;
        
    }  
    
}

// you are done when =1 in the base case
